﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    public class AccountManagment
    {
        public Patient Patient
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }

        public Doctor Doctor
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }
    }
}
