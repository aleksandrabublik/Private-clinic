﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    public class Doctor : BasedAccount
    {
        public IntroductionInternship IntroductionInternship
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }

        public Courses Courses
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }

        public Shedule Shedule
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }
    }
}
