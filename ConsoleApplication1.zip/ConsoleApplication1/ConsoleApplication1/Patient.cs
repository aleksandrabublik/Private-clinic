﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    public class Patient : BasedAccount
    {
        public Feedback Feedback
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }

        public Medicine Medicine
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }

        public Shedule Shedule
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }
    
        public void Viewshedule()
        {
            throw new System.NotImplementedException();
        }
    }
}
